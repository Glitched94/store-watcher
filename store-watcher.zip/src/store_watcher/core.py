from __future__ import annotations
import os, re, time, traceback
from datetime import timedelta
from typing import Dict, Iterable, Set, List, Tuple

from dotenv import load_dotenv
from .utils import make_session, utcnow_iso, iso_to_dt, domain_of, site_label
from .state import load_state, save_state, make_present_record, migrate_keys_to_composite
from .adapters.base import Adapter, Item
from .adapters.sfcc import SFCCGridAdapter
from .notify import build_notifiers_from_env, render_change_digest, Notifier

ADAPTERS: Dict[str, Adapter] = {
    # we can reuse the same adapter for all Disney regions
    "sfcc": SFCCGridAdapter(),
    "disneystore": SFCCGridAdapter(),  # alias for convenience
}

def _compile(rx: str | None):
    return re.compile(rx) if rx else None

def _split_urls(urls: str) -> List[str]:
    # split by comma or newline; strip empties
    parts = [p.strip() for p in re.split(r"[,\n]", urls) if p.strip()]
    # de-dup, preserve order
    seen = set(); out=[]
    for p in parts:
        if p not in seen:
            seen.add(p); out.append(p)
    return out

def run_watcher(
    site: str,
    url_override: str | None,
    interval: int,
    restock_hours: int,
    include_re: str | None,
    exclude_re: str | None,
    once: bool,
    dotenv_path: str | None = None,
) -> None:
    # dotenv
    load_dotenv(dotenv_path=dotenv_path)

    adapter = ADAPTERS.get(site) or ADAPTERS["sfcc"]

    # accept TARGET_URL or TARGET_URLS (multi)
    env_single = os.getenv("TARGET_URL", "").strip()
    env_multi  = os.getenv("TARGET_URLS", "").strip()
    urls: List[str] = []

    if url_override:
        urls = _split_urls(url_override)
    elif env_multi:
        urls = _split_urls(env_multi)
    elif env_single:
        urls = [env_single]

    if not urls:
        raise SystemExit("Set TARGET_URL or TARGET_URLS in .env, or pass --url/--urls")

    default_host = domain_of(urls[0])

    include_rx = _compile(include_re or os.getenv("INCLUDE_RE", "").strip() or None)
    exclude_rx = _compile(exclude_re or os.getenv("EXCLUDE_RE", "").strip() or None)
    restock_delta = timedelta(hours=restock_hours)

    from pathlib import Path
    state_path = Path(os.getenv("STATE_FILE", "seen_items.json"))

    notifiers: list[Notifier] = build_notifiers_from_env()
    if not notifiers:
        print("[warn] No notifiers configured (set SMTP_* or DISCORD_WEBHOOK_URL). Will log only.")

    print(f"[info] Watching {len(urls)} URL(s) via adapter={site}")
    for u in urls:
        print(f"       - {u} [{site_label(u)}]")
    if include_rx: print(f"[info] Include: {include_rx.pattern}")
    if exclude_rx: print(f"[info] Exclude: {exclude_rx.pattern}")
    print(f"[info] Restock window: {restock_hours}h")
    print(f"[info] State file: {state_path}")
    print(f"[info] Notifiers: {', '.join(type(n).__name__ for n in notifiers) or 'none'}")

    state = load_state(state_path)
    state = migrate_keys_to_composite(state, default_host)
    save_state(state, state_path)
    print(f"[info] Known items: {len(state)}")

    session = make_session()

    def tick() -> None:
        nonlocal state
        now_iso = utcnow_iso()
        now_dt = iso_to_dt(now_iso)

        # Per-site collections for grouping
        site_current_counts: Dict[str, int] = {}
        site_new: Dict[str, List[str]] = {}
        site_restocked: Dict[str, List[str]] = {}

        # Track which composite keys are present this tick
        present_keys: Set[str] = set()
        url_for_key: Dict[str, str] = {}
        name_for_key: Dict[str, str] = {}

        # 1) Fetch each URL
        for url in urls:
            host = domain_of(url)
            label = site_label(url)
            items: Iterable[Item] = adapter.fetch(
                session=session,
                url=url,
                include_rx=include_rx,
                exclude_rx=exclude_rx,
            )
            count = 0
            for it in items:
                count += 1
                key = f"{host}:{it.code}"
                present_keys.add(key)
                if it.url:
                    url_for_key[key] = it.url
                if it.title:
                    name_for_key[key] = it.title
            site_current_counts[label] = site_current_counts.get(label, 0) + count

        # 2) Mark absences
        for key, info in state.items():
            if key not in present_keys and info.get("status", 1) == 1:
                info["status"] = 0
                info["status_since"] = now_iso

        # 3) Handle present items
        for key in present_keys:
            preferred_url = url_for_key.get(key, state.get(key, {}).get("url", ""))
            preferred_name = name_for_key.get(key, state.get(key, {}).get("name", None))

            if key not in state:
                # inject host into the record too
                host, _code = key.split(":", 1)
                state[key] = make_present_record(preferred_url, now_iso, preferred_name, host=host)
                lab = site_label(host)
                site_new.setdefault(lab, []).append(key)
            else:
                info = state[key]
                if preferred_url and preferred_url != info.get("url", ""):
                    info["url"] = preferred_url
                if preferred_name and preferred_name != info.get("name"):
                    info["name"] = preferred_name
                info.setdefault("host", key.split(":", 1)[0])  # ensure host exists
                if info.get("status", 0) == 0:
                    absent_since = iso_to_dt(info.get("status_since", now_iso))
                    if now_dt - absent_since >= restock_delta:
                        lab = site_label(key.split(":", 1)[0])
                        site_restocked.setdefault(lab, []).append(key)
                    info["status"] = 1
                    info["status_since"] = now_iso
                else:
                    info["status"] = 1

        # 4) Persist
        save_state(state, state_path)

        # 5) Notify, grouped by site
        # Flatten per-site into code lists understood by renderer (we’ll look up name/url from state)
        new_codes: List[str] = []
        restocked_codes: List[str] = []
        # We encode the site label into the code list by just passing composite keys; notify will pretty-print names/links
        for lab, keys in site_new.items():
            new_codes.extend(keys)
        for lab, keys in site_restocked.items():
            restocked_codes.extend(keys)

        # Total items across all sites this tick
        total_now = sum(site_current_counts.values())

        if new_codes or restocked_codes:
            subject, html_body, text_body = render_change_digest(
                new_codes=new_codes,
                restocked_codes=restocked_codes,
                state=state,
                restock_hours=restock_hours,
                target_url="(multiple)",      # not shown in messages
                total_count=total_now,
            )
            for n in notifiers:
                try:
                    n.send(subject, html_body, text_body)
                except Exception:
                    traceback.print_exc()

        print(f"[info] tick: total={total_now} new={len(new_codes)} restocked={len(restocked_codes)} known={len(state)}")

    while True:
        try:
            tick()
        except Exception:
            traceback.print_exc()
        if once:
            break
        time.sleep(interval)
